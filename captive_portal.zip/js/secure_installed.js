function redirectSecure() {
window.location.replace('http://untangle.tower.local/capture/handler.py/index?appid=14');
window.location.href = "http://untangle.tower.local/capture/handler.py/index?appid=14";
}
